const timerEl = document.getElementById("timer");
const leadForm = document.getElementById("leadForm");
const paymentPanel = document.getElementById("paymentPanel");
const downloadPanel = document.getElementById("downloadPanel");
const verifyPayment = document.getElementById("verifyPayment");
const stepLead = document.getElementById("stepLead");
const stepPay = document.getElementById("stepPay");
const stepDone = document.getElementById("stepDone");
const studentNameInput = document.getElementById("studentName");
const whatsappInput = document.getElementById("whatsapp");
const paymentScreenshot = document.getElementById("paymentScreenshot");
const paymentNote = document.getElementById("paymentNote");
const purchaseHistory = document.getElementById("purchaseHistory");
const historySection = document.getElementById("history");

let remainingSeconds = 15 * 60;
let currentLead = null;
const historyKey = "raviSirNotesPurchaseHistory";
const isOwnerView = new URLSearchParams(window.location.search).get("admin") === "ravi";

function renderTimer() {
  const minutes = Math.floor(remainingSeconds / 60).toString().padStart(2, "0");
  const seconds = (remainingSeconds % 60).toString().padStart(2, "0");
  timerEl.textContent = `${minutes}:${seconds}`;

  if (remainingSeconds > 0) {
    remainingSeconds -= 1;
  }
}

function setActiveStep(activeStep) {
  [stepLead, stepPay, stepDone].forEach((step) => step.classList.remove("active"));
  activeStep.classList.add("active");
}

function getHistory() {
  try {
    return JSON.parse(localStorage.getItem(historyKey)) || [];
  } catch (error) {
    return [];
  }
}

function saveHistory(history) {
  localStorage.setItem(historyKey, JSON.stringify(history.slice(0, 12)));
}

function maskPhone(phone) {
  return phone.replace(/^(\d{2})\d{5}(\d{3})$/, "$1*****$2");
}

function escapeHtml(value) {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function renderHistory() {
  if (!isOwnerView) {
    return;
  }

  const history = getHistory();

  if (!history.length) {
    purchaseHistory.innerHTML = '<p class="empty-history">No student purchase yet. New verified buyers will appear here.</p>';
    return;
  }

  purchaseHistory.innerHTML = history.map((item) => `
    <div class="history-row">
      <strong>${escapeHtml(item.name)}</strong>
      <span>${escapeHtml(maskPhone(item.whatsapp))}</span>
      <span class="paid-badge">Paid ₹49</span>
      <time>${escapeHtml(item.time)}</time>
    </div>
  `).join("");
}

function addPurchaseToHistory(lead) {
  const history = getHistory();
  const now = new Date();
  history.unshift({
    name: lead.name,
    whatsapp: lead.whatsapp,
    time: now.toLocaleString("en-IN", {
      day: "2-digit",
      month: "short",
      hour: "2-digit",
      minute: "2-digit"
    })
  });
  saveHistory(history);
  renderHistory();
}

renderTimer();
setInterval(renderTimer, 1000);

if (isOwnerView) {
  historySection.classList.remove("hidden");
  renderHistory();
}

leadForm.addEventListener("submit", (event) => {
  event.preventDefault();

  if (!leadForm.checkValidity()) {
    leadForm.reportValidity();
    return;
  }

  currentLead = {
    name: studentNameInput.value.trim(),
    whatsapp: whatsappInput.value.trim()
  };

  leadForm.classList.add("hidden");
  paymentPanel.classList.remove("hidden");
  setActiveStep(stepPay);
  paymentPanel.scrollIntoView({ behavior: "smooth", block: "center" });
});

paymentScreenshot.addEventListener("change", () => {
  const hasScreenshot = paymentScreenshot.files.length > 0;
  verifyPayment.disabled = !hasScreenshot;
  paymentNote.textContent = hasScreenshot
    ? "Screenshot uploaded. Ab payment verify karke group link unlock karein."
    : "Payment screenshot upload karne ke baad hi WhatsApp group link unlock hoga.";
});

verifyPayment.addEventListener("click", () => {
  if (!paymentScreenshot.files.length) {
    paymentNote.textContent = "Pehle payment screenshot upload karein.";
    paymentScreenshot.focus();
    return;
  }

  verifyPayment.disabled = true;
  verifyPayment.textContent = "Verifying...";

  setTimeout(() => {
    paymentPanel.classList.add("hidden");
    downloadPanel.classList.remove("hidden");
    setActiveStep(stepDone);
    if (currentLead) {
      addPurchaseToHistory(currentLead);
    }
    downloadPanel.scrollIntoView({ behavior: "smooth", block: "center" });
  }, 900);
});
